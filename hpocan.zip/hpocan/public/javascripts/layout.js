$(document).ready(function (){
  $('a').each(function() {
    if ($(this).prop('href') == window.location.href) {
      $(this).parent().addClass('active');
    }
  });
});